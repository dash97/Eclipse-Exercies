package com.amdocs;

public class Hello {
	//main method
	public static void main(String[] args) {
		
		System.out.println("Hello Java!");
	}

}
