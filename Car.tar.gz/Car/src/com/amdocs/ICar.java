package com.amdocs;

public interface ICar {
	
	public static void drive() {
		
	}

}
