package com.amdocs;

public class Audi implements ICar {

	public void drive() {
		System.out.println("Driving Audi");
	}
}
