package com.amdocs;

public class NullCar implements ICar {
	
	public void drive() {
		System.out.println("Not feasible");
	}

}
