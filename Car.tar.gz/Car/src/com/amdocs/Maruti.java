package com.amdocs;

public class Maruti implements ICar {
	
	public void drive() {
		System.out.println("Driving Maruti");
	}

}
