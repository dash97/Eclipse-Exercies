package com.amdocs;

public interface IObserver {
	
	public void update(String message);

}
