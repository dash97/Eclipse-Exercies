package com.amdocs;

public interface IMobile {
	
	public void call();
}
