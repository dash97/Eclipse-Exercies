package com.amdocs;

public class IPhone4 implements IMobile {

	public void call() {
		
			System.out.println("Calling from iPhone4 ...");
			
	}

}
