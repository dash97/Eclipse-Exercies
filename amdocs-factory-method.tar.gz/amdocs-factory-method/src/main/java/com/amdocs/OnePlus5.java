package com.amdocs;

public class OnePlus5 implements IMobile {

	public void call() {

		System.out.println("Calling from Oneplus5 ...");

	}

}
