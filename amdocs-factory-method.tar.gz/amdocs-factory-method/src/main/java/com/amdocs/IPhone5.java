package com.amdocs;

public class IPhone5 implements IMobile {

	public void call() {

		System.out.println("Calling from iPhone5 ...");
	
	}

}
