package com.amdocs;

public class HeapSort implements IAlgorithm {

	public void sort() {
		
		System.out.println("Heapsort algorithm invoked ...");

	}

}
