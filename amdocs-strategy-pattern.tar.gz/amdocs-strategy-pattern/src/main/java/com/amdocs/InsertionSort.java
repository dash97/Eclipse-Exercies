package com.amdocs;

public class InsertionSort implements IAlgorithm {

	public void sort() {
		
		System.out.println("Insertionsort algorithm invoked ...");

	}

}
