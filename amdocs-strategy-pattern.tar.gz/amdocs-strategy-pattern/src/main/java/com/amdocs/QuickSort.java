package com.amdocs;

public class QuickSort implements IAlgorithm {

	public void sort() {
		
		System.out.println("Quicksort algorithm invoked ...");

	}

}
