package com.amdocs;

public class NullAlgorithm implements IAlgorithm {

	public void sort() {
		
		System.out.println("Invalid sort invoked");
		System.out.println("Perform error log and error handling here");
	}

}
