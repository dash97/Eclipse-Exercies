package com.amdocs;

public class Camera {

	public boolean on() {
		System.out.println("Camera on method");
		System.out.println("Assume Camera hardware interaction happens here");
		return true;
	}
	
	

}
